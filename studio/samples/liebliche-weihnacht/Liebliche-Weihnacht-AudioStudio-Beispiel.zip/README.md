# Audio Studio – Beispielalbum „Liebliche Weihnacht"

Dieses Beispiel enthält die 12 Stücke des Albums mit den originalen Partituren
(`composition.json`), den gespeicherten Mix-Einstellungen, zugehörigem MIDI,
Albumplanung und einer Cover-Abbildung.

## In Audio Studio importieren

1. `Liebliche-Weihnacht-Projektimport.zip` über **Projekt importieren** öffnen.
2. Das Album **Liebliche Weihnacht** im importierten Projekt auswählen.
3. Die benötigten Instrumentenbibliotheken lokal installieren bzw. zuweisen.
4. Die Stücke neu rendern und auf Wunsch das Album exportieren.

`Liebliche Weihnacht.cue` ist eine Referenz-CUE-Datei: Sie benennt WAV-Stücke,
die aus Platzgründen nicht Bestandteil dieses Beispiels sind.
Die beigelegte Abbildung ist das vollständige Klappcover und nicht die Einzel-WAV-Datei.

Quelle: exportiertes Audio-Studio-Projekt vom 17. November 2026.
Entfernt wurden alle projektfremden Alben/Stücke, gespeicherte KI-Antworten,
private Anwendungseinstellungen und generierte Audio-Renderings.
